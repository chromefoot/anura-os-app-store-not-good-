
# Anura OS App Repository

This is a starter repo for the Anura OS Marketplace.

## Structure

```
anura-repo/
├─ apps.json          # index file consumed by the marketplace
├─ apps/
│  └─ sample-app.zip  # zipped .app bundle(s)
└─ icons/
   └─ sample.png      # icons for apps
```

## How to Publish

1. Replace `YOUR-USERNAME` in `apps.json` with your GitHub username.
2. Add your own apps to `apps/` as `.zip` files of `.app` bundles.
3. Add app icons to `icons/` and point each app's `icon` to the raw URL.
4. Commit & push to a public repo named `anura-repo` (or any name you like).
5. In Anura Marketplace, add the repo URL:
   ```
   https://raw.githubusercontent.com/<YOUR-USERNAME>/<YOUR-REPO>/main/apps.json
   ```

> Note: Until you upload to GitHub and fix the URLs, installs will 404 (file not found).

## Sample App

The sample app demonstrates the expected bundle contents:

```
sample-app/
├─ manifest.json  # includes id, name, version, and entry (index.html)
└─ index.html
```

When zipped, it becomes `apps/sample-app.zip` and should be referenced by a **raw** GitHub URL in `apps.json`.
